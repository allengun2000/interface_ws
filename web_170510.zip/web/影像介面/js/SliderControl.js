//
function showValue(newValue, name, num) {
    document.getElementsByName(name)[num].innerText = newValue;
}

// function rangeValue(newValue) {
//     document.getElementById("RobotRange3").value = newValue;
// }

//======================================================================
